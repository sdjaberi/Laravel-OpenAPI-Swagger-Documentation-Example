<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="Dutch">
  <context>
    <name/>
    <message>
      <source>Settings</source>
      <translation type="unfinished"></translation>
    </message>
  </context>
  <context>
    <name>AccountScheme</name>
    <message>
      <source>Please note, any overrides will lead to static phrases, which are not translateable.</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Reset to default</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Details</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Sampling Points Scheme</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>You can override the sampling point data fields here. This will be visible in the sampling point detail view, as well as on generated reports, etc..</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Name</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Identifier</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Customer ID</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Notes</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Address</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Street</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>ZIP</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>City</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Canton</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Country</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Contact</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Email</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Phone 1</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Phone 2</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Fax</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Default restored !</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Saved !</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Telephone 1</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Telephone 2</source>
      <translation type="unfinished"></translation>
    </message>
  </context>
  <context>
    <name>Accounts</name>
    <message>
      <source>Accounts</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Sampling Points</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Search</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Add Sampling Point</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Delete selected Sampling Points</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>No sampling points selected</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Add Account</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Delete selected Accounts</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>No accounts selected</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>You don't have the permission for this operation.</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Are you sure to delete the selected accounts?</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Please confirm delete operation</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Are you sure to delete the selected account?</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Applications</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Add Application</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Delete selected Applications</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>No application selected</source>
      <translation type="unfinished"></translation>
    </message>
  </context>
  <context>
    <name>AccountsDataScheme</name>
    <message>
      <source>Accounts Scheme</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>You can override the account data fields here. This will be visible in the account detail view, as well as on generated reports, etc..</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Please note, any overrides will lead to static phrases, which are not translateable.</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Reset to default</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Default restored !</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Details</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Saved !</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Forename</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Surname</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Customer ID</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Notes</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Address</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Street</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Zip</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>City</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Canton</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Country</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Contact</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Email</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Telephone 1</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Telephone 2</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Fax</source>
      <translation type="unfinished"></translation>
    </message>
  </context>
  <context>
    <name>ActivateParameter</name>
    <message>
      <source>Activate Parameter</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Activate</source>
      <translation type="unfinished"></translation>
    </message>
  </context>
  <context>
    <name>ActiveChlorine</name>
    <message>
      <source>Active Chlorine</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>pH Value</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Temperature (°C)</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>free Chlorine</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>CYA</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Kills some algae and bacteria</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Kills algae and bacteria</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Outer Circle</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Inner Circle</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Input error</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>unbound Chlorine:</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>bound to CYA:</source>
      <translation type="unfinished"></translation>
    </message>
  </context>
  <context>
    <name>ActiveChorine</name>
    <message>
      <source>0.05ppm HOCl are required for basic desinfection</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>0.32ppm HOCl are required to kill stronger viruses like e.g. the Coxsackie virus </source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Active Chlorine</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>pH Value</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Temperature (°C)</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>free Chlorine</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>CYA</source>
      <translation type="unfinished"></translation>
    </message>
  </context>
  <context>
    <name>ActiveParameters</name>
    <message>
      <source>Active Parameters</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>not yet released</source>
      <translation type="unfinished"></translation>
    </message>
  </context>
  <context>
    <name>AddManualMeasurement</name>
    <message>
      <source>Manual Measurement</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Please check inputs !</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Operator</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Select Test</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Measurement value</source>
      <translation type="unfinished"></translation>
    </message>
  </context>
  <context>
    <name>AddWifi</name>
    <message>
      <source>Add WiFi</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Password</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Connect</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>connecting ...</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Successfully connected</source>
      <translation type="unfinished"></translation>
    </message>
  </context>
  <context>
    <name>AppQrCodes</name>
    <message>
      <source>LabCom App</source>
      <translation type="unfinished"></translation>
    </message>
  </context>
  <context>
    <name>AppStateStore</name>
    <message>
      <source>TEST</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Smartchamber Mode</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Sampling Points</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Chemistry</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Favorites</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Cloud</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Parameter</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>QR Scanner</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Ideal Ranges</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Calculator</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Support</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Power Menu</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Settings</source>
      <translation type="unfinished"></translation>
    </message>
  </context>
  <context>
    <name>AudioTest</name>
    <message>
      <source>Audio Test</source>
      <translation type="unfinished"></translation>
    </message>
  </context>
  <context>
    <name>BluetoothSettings</name>
    <message>
      <source>Bluetooth</source>
      <translation type="unfinished"></translation>
    </message>
  </context>
  <context>
    <name>CELab</name>
    <message>
      <source>CE Lab settings</source>
      <translation type="unfinished"></translation>
    </message>
  </context>
  <context>
    <name>Calibration</name>
    <message>
      <source>Calibration and Indexation</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Calibration</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Last taken:</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Indexation</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Indexing Cuvette</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Define cuvette orientation for Turbidity</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Calibration Certificates</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Upload current calibration certificate</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>No newer calibrations than previously uploaded!</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Please check your internet connection!</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Server error</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Certificate uploaded</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>You will receive an email containing a link to your certificates.</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Email for notification</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Certificate Website</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Device Serial</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Authorization Key</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>factory calibration</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Turbidity</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>never</source>
      <translation type="unfinished"></translation>
    </message>
  </context>
  <context>
    <name>CameraTest</name>
    <message>
      <source>Camera Test</source>
      <translation type="unfinished"></translation>
    </message>
  </context>
  <context>
    <name>Chemistry</name>
    <message>
      <source>Water Treatment Products</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Manage your chemistry for water treatment</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Hardness Conversion</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>convert different hardness units</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>RSI/LSI Index</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Langelier Saturation Index, Ryznar Stability Index</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Active Chlorine</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>calculate the acutal active chlorine</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Dosage Recommendation</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>calculate the required amount of water treatment products</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Chemistry</source>
      <translation type="unfinished"></translation>
    </message>
  </context>
  <context>
    <name>ChooseOEM</name>
    <message>
      <source>Checking for updates</source>
      <translation type="unfinished"></translation>
    </message>
  </context>
  <context>
    <name>Cloud</name>
    <message>
      <source>Checking for unsynchronized data!</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Please check your internet connection!</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Logged in as</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Total Accounts</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Total Sampling Points</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Total Measurements</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Last updated</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Website for managing your data</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>LabCom App</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Show QR code for app download</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>You are currently not connected to the cloud service. Please log in or create a free cloud account.</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Login</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Register</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Cloud</source>
      <translation type="unfinished"></translation>
    </message>
  </context>
  <context>
    <name>CloudLogin</name>
    <message>
      <source>Cloud Login</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Email</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Password</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Upload local data?</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Login</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>connecting ...</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>synchronizing cloud data</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Network error</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Protocol error</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Password or email invalid</source>
      <translation type="unfinished"></translation>
    </message>
  </context>
  <context>
    <name>CloudSignup</name>
    <message>
      <source>Cloud Signup</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Email</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Password</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Repeat Password</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Network Error</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Protocol Error</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Email already taken, please login</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>An error occured, please retry</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Upload local data?</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Register</source>
      <translation type="unfinished"></translation>
    </message>
  </context>
  <context>
    <name>ConnectWifi</name>
    <message>
      <source>Password can't be empty!</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>connecting ...</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Successfully connected</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Please check password</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Add WiFi</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Password</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Connect</source>
      <translation type="unfinished"></translation>
    </message>
  </context>
  <context>
    <name>ConnectionSettings</name>
    <message>
      <source>Connections</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>WiFi</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Currently we don't have any functionality for Bluetooth.</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Bluetooth</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Settings</source>
      <translation type="unfinished"></translation>
    </message>
  </context>
  <context>
    <name>CreateAccount</name>
    <message>
      <source>New Account</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Saved !</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Please check inputs !</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Details</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Address</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Contact</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Forename</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Surname</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>New Sampling Point</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Name</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Identifier</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Water volume [m³]</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Customer ID</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Notes</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Street</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Zip</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>City</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Canton</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Country</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Email</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Telephone 1</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Telephone 2</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Fax</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>New Application</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>LubeAnalyst Machine Code</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>e.g.</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Customer Component ID</source>
      <translation type="unfinished"></translation>
    </message>
  </context>
  <context>
    <name>CreateOperator</name>
    <message>
      <source>New Operator</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Please check inputs !</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Name</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Operator name</source>
      <translation type="unfinished"></translation>
    </message>
  </context>
  <context>
    <name>CreateWTP</name>
    <message>
      <source>New WTP</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>New Product</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Please check inputs !</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Product name</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Product amount</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Select Unit</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Select parameter group</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Product effect value</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Effected water volume</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Water volume unit</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>%a%b of %c %d the %e value by %f per %g%h water.</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>PRODUCT-UNIT</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>PRODUCT-NAME</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>lowers</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>raises</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>PARAMETER-GROUP</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>WATER-UNIT</source>
      <translation type="unfinished"></translation>
    </message>
  </context>
  <context>
    <name>DataScheme</name>
    <message>
      <source>Data Scheme</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Sampling points scheme</source>
      <translation type="unfinished"></translation>
    </message>
  </context>
  <context>
    <name>DesignConfirmPopup</name>
    <message>
      <source>Cancel</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Confirm</source>
      <translation type="unfinished"></translation>
    </message>
  </context>
  <context>
    <name>DesignDatePicker</name>
    <message>
      <source>January</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>February</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>March</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>April</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>May</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>June</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>July</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>August</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>September</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>October</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>November</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>December</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Sunday</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Monday</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Tuesday</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Wednesday</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Thursday</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Friday</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Saturday</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>OK</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>CANCEL</source>
      <translation type="unfinished"></translation>
    </message>
  </context>
  <context>
    <name>DesignMultiSelect</name>
    <message>
      <source>no options selected</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>OK</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>CANCEL</source>
      <translation type="unfinished"></translation>
    </message>
  </context>
  <context>
    <name>DeviceInformation</name>
    <message>
      <source>Device Information</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Check for Updates</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Please check your internet connection</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Loading...</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Update parameters</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Parameters up to date</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Error, parameters can't be fetched</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Database Version</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Firmware Version</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>IP Address</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Checking for updates</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>OS Version</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Serial Number</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Brand</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Legal Notices</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Factory reset</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>All data, except for activated parameters, will be lost. Continue?</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Please note the device will poweroff automatically.</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Factory reset?</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>No</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Yes</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Settings</source>
      <translation type="unfinished"></translation>
    </message>
  </context>
  <context>
    <name>DialogMiddleware</name>
    <message>
      <source>Permission Denied</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>You don't have the permission for this operation.</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Confirmation</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Are you sure to delete the selected sampling points?</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Are you sure to delete the selected measurements?</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Are you sure to delete the selected products?</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>All data, except for activated parameters, will be lost. Continue?</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Please note the device will poweroff automatically.</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source> updates available</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Copy updates from USB drive?</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Download all updates?</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Download complete</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Start installation?</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Installation complete</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>The system needs to be restarted. Restart now?</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Warning, battery low</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Battery too low, you can't take measurements or install updates below 15% battery charge.</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Download failed</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>An error occured, please retry.</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Retry now</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Installation failed</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Please retry later. Do you want to restart the system now?</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Reboot now</source>
      <translation type="unfinished"></translation>
    </message>
  </context>
  <context>
    <name>Display</name>
    <message>
      <source>Display</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Display Brightness</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Background</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Enable Display Dimming</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Enable Auto Sleep</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Minutes</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Enable Auto Poweroff</source>
      <translation type="unfinished"></translation>
    </message>
  </context>
  <context>
    <name>DisplaySettings</name>
    <message>
      <source>Show Menubutton on Homescreen</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Enable Screensaver</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Enable Auto Sleep</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Minutes</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Saved!</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Enable Auto Poweroff</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Settings</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Display</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Display Brightness</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Background</source>
      <translation type="unfinished"></translation>
    </message>
  </context>
  <context>
    <name>DosageRecommendation</name>
    <message>
      <source>Select Group</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Dosage Recommendation</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Water volume</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Unit</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Parameter group</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Current value</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Target value</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Calculate</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Target value equals current value</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>No matching products found</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Water volume [m³]</source>
      <translation type="unfinished"></translation>
    </message>
  </context>
  <context>
    <name>EditAccount</name>
    <message>
      <source>Nothing has been edited !</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Details</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Address</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Contact</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Forename</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Surname</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Name</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Identifier</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Water volume [m³]</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Customer ID</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Notes</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Street</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Zip</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>City</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Canton</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Country</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Email</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Telephone 1</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Telephone 2</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Fax</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Saved !</source>
      <translation type="unfinished"></translation>
    </message>
  </context>
  <context>
    <name>EditMeasurement</name>
    <message>
      <source>Value</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Operator</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Comment</source>
      <translation type="unfinished"></translation>
    </message>
  </context>
  <context>
    <name>EditOperator</name>
    <message>
      <source>Edit Operator</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Please check inputs !</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Name</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Operator name</source>
      <translation type="unfinished"></translation>
    </message>
  </context>
  <context>
    <name>EditWTP</name>
    <message>
      <source>Edit WTP</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Saved !</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Edit Product</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Please check inputs !</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Product name</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Product amount</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Select Unit</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Select parameter group</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Product effect value</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Effected water volume</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Water volume unit</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>%a%b of %c %d the %e value by %f per %g%h water.</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>PRODUCT-NAME</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>lowers</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>raises</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>PARAMETER-GROUP</source>
      <translation type="unfinished"></translation>
    </message>
  </context>
  <context>
    <name>Favorites</name>
    <message>
      <source>shortcut already exists</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>shortcut added to homescreen</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Favorites</source>
      <translation type="unfinished"></translation>
    </message>
  </context>
  <context>
    <name>General</name>
    <message>
      <source>General Settings</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Timezone, Country and Language</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Select Timezone</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Select Country</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Select Language</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Date and Time</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>automatic</source>
      <translation type="unfinished"></translation>
    </message>
  </context>
  <context>
    <name>GeneralSettings</name>
    <message>
      <source>General</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Country and Language</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Select Timezone</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Saved!</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Select Country</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Select Language</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Date and Time</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>automatic</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Date</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Time</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Settings</source>
      <translation type="unfinished"></translation>
    </message>
  </context>
  <context>
    <name>HardnessConversion</name>
    <message>
      <source>Value to convert</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Select Unit</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Hardness Conversion</source>
      <translation type="unfinished"></translation>
    </message>
  </context>
  <context>
    <name>IdealRangeDelegate</name>
    <message>
      <source>From</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>To</source>
      <translation type="unfinished"></translation>
    </message>
  </context>
  <context>
    <name>IndexingCuvette</name>
    <message>
      <source>Remove the cuvette and mark it with a waterproof pen at the indicated side above the 10ml line.</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Insert the cuvette and turn it according to the image above. Press MEASURE to take a shot and proceed to the next step.</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Validate</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Measure</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>taking measurement</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Next Step</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Finish</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Indexing Cuvette</source>
      <translation type="unfinished"></translation>
    </message>
  </context>
  <context>
    <name>IndexingCuvettePreset</name>
    <message>
      <source>Next</source>
      <translation type="unfinished"></translation>
    </message>
  </context>
  <context>
    <name>LabInternal</name>
    <message>
      <source>Lab Internal</source>
      <translation type="unfinished"></translation>
    </message>
  </context>
  <context>
    <name>LegalNotices</name>
    <message>
      <source>Open Source Licenses</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>follows soon</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Privacy Policy</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Terms and Conditions</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Safety Instructions</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>EULA</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Legal Notices</source>
      <translation type="unfinished"></translation>
    </message>
  </context>
  <context>
    <name>LocalSelection</name>
    <message>
      <source>Configuring</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Location settings</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Please select your country so I know on which frequencies to scan for your WiFi. Also, choose the language you want me to use to communicate with you.</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Select Timezone</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Select Country</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Select Language</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Continue</source>
      <translation type="unfinished"></translation>
    </message>
  </context>
  <context>
    <name>Lockscreen</name>
    <message>
      <source>Please set a code</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Please enter your code to disable the lock screen</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation type="unfinished"></translation>
    </message>
  </context>
  <context>
    <name>MainMenu</name>
    <message>
      <source>CE LAB</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Smartchamber</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Settings</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>TEST</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Chemistry</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Accounts</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>QR Scanner</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Favorites</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Cloud</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Parameters</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Ideal Ranges</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Calculator</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Support</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Battery Warning</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Are your sure to power off the device?</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Poweroff System</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Add to homescreen</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Camera Test</source>
      <translation type="unfinished"></translation>
    </message>
  </context>
  <context>
    <name>MainMenuIcon</name>
    <message>
      <source>Remove</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Add to homescreen</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>shortcut already exists</source>
      <translation type="unfinished"></translation>
    </message>
  </context>
  <context>
    <name>MainWindow</name>
    <message>
      <source>PrimeLab 2.0</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Update in progress!</source>
      <translation type="unfinished"></translation>
    </message>
  </context>
  <context>
    <name>MeasurementDelegate</name>
    <message>
      <source>not found</source>
      <translation type="unfinished"></translation>
    </message>
  </context>
  <context>
    <name>MeasurementDetails</name>
    <message>
      <source>Method</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>manual</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Parameter</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Value</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Test range</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Dilution factor</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Comment</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Operator</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Ideal range</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Status</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Date</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Device serial</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Last changed</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Details</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>You don't have the permission for this operation.</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Select Unit</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>not found</source>
      <translation type="unfinished"></translation>
    </message>
  </context>
  <context>
    <name>MeasurementHistory</name>
    <message>
      <source>History</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Revision Time</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Measurement Date</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Value</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Ideal Range</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Comment</source>
      <translation type="unfinished"></translation>
    </message>
  </context>
  <context>
    <name>MeasurementStore</name>
    <message>
      <source>Saved</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Deleted</source>
      <translation type="unfinished"></translation>
    </message>
  </context>
  <context>
    <name>Measurements</name>
    <message>
      <source>Filter measurements</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>New measurement</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Delete selected measurements</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Dosage recommendation</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>No measurements selected</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Hide OR/UR</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Parameter</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>no options selected</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Date range</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>custom range</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>From date</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>To date</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>You don't have the permission for this operation.</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Are you sure to delete the selected measurements?</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Please confirm delete operation</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Are you sure to delete the selected measurement?</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Filter active</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Hide Underrange/Overrange</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>today</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>last 3 days</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>--- clear date filter ---</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>last 5 days</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>last 7 days</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>this month</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>last month</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>custom date range</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>clear date filter</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Filter by date</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>From</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>To</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Add manual measurement</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Not supported by this application</source>
      <translation type="unfinished"></translation>
    </message>
  </context>
  <context>
    <name>MultiSelectInput</name>
    <message>
      <source>options selected</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>no options selected</source>
      <translation type="unfinished"></translation>
    </message>
  </context>
  <context>
    <name>MultiSelectNavigation</name>
    <message>
      <source>Delete</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Delete selected</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation type="unfinished"></translation>
    </message>
  </context>
  <context>
    <name>NewMeasurement</name>
    <message>
      <source>Favorite already exists!</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Favorite Overview</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Selected Parameter</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Selected Account</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Favorite Name</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Save</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Saved !</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Select Parameter</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Please select account and parameter</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Select Account</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Select Operator</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Water Sample</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Dilution Solution</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>You can define an individual dilution factor in order to increase the measurement range.</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Please note:</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>The step-by-step phrases during the measurement process do NOT consider any dilution settings, just the result will be calculated according to the selected dilution factor.</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Dilution increases the tolerances/accuracy of the measurement result</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Start measurement</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>New Measurement</source>
      <translation type="unfinished"></translation>
    </message>
  </context>
  <context>
    <name>News</name>
    <message>
      <source>News</source>
      <translation type="unfinished"></translation>
    </message>
  </context>
  <context>
    <name>Operators</name>
    <message>
      <source>Operators</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Search</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Add Operator</source>
      <translation type="unfinished"></translation>
    </message>
  </context>
  <context>
    <name>ParameterOverview</name>
    <message>
      <source>Show active Parameter</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Request Parameter</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Parameter</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Search</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Activate Parameter</source>
      <translation type="unfinished"></translation>
    </message>
  </context>
  <context>
    <name>PowerOffPopup</name>
    <message>
      <source>Sleep</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Power off</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Reboot</source>
      <translation type="unfinished"></translation>
    </message>
  </context>
  <context>
    <name>PrimelabStore</name>
    <message>
      <source>Device connected to network</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Error, parameters can't be fetched</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Parameters up to date</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Please check your internet connection</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>factory calibration</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>never</source>
      <translation type="unfinished"></translation>
    </message>
  </context>
  <context>
    <name>PushToLubeAnalyst</name>
    <message>
      <source>Pending Measurement Records</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Automatic Upload</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Upload to</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>connecting to Lube Analyst ...</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>An error occured, please re-try</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Applications</source>
      <translation type="unfinished"></translation>
    </message>
  </context>
  <context>
    <name>QRScanner</name>
    <message>
      <source>Parameters successfully activated.</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>The reagent is expired. Using this reagent might lead to inaccurate results.</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>The scanned code is not supported by the device.</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Scan</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Reagent scanned</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Name</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Item Code</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Exp. Date</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Select Parameter</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Continue</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>QR Scanner</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Scan again</source>
      <translation type="unfinished"></translation>
    </message>
  </context>
  <context>
    <name>RSI</name>
    <message>
      <source>Temperature</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>pH Value</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Alaklinity (ppm CaCO3)</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Alkalinity (ppm CaCO3)</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Hardness (ppm Ca2+)</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Total dissolved solids</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>pHs Value</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>LSI Index</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>RSI Index</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>RSI/LSI Index</source>
      <translation type="unfinished"></translation>
    </message>
  </context>
  <context>
    <name>RequestParameters</name>
    <message>
      <source>Request Parameters</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Email</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Request sent. We will get in contact with you soon.</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Please check your internet connection</source>
      <translation type="unfinished"></translation>
    </message>
  </context>
  <context>
    <name>RunCalibration</name>
    <message>
      <source>Step </source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>CALIBRATE</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Calibration successful</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Calibration</source>
      <translation type="unfinished"></translation>
    </message>
  </context>
  <context>
    <name>RunScenario</name>
    <message>
      <source>Are you sure to quit the ongoing measurement?, all unsaved data will be lost.</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Quit measurement</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Step</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Please choose</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Select option</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Confirm</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Please check if the cuvette adapter is inserted properly.</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Adapter Error</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Continue ZERO</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Ignore</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Do you want to reuse your last ZERO?</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Reuse ZERO?</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>YES</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>NO</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>You are missing a required calibration for this measurement.</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Error, missing calibration</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Calibrate</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Exit Measurement</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Results Overview</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Select Unit</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Countdown</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Professional mode enabled</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>This mode deactivates all phrases and animations.</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>You can disable this mode in the settings.</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Uploading data ...</source>
      <translation type="unfinished"></translation>
    </message>
  </context>
  <context>
    <name>Security</name>
    <message>
      <source>Security</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Enable Lock Screen</source>
      <translation type="unfinished"></translation>
    </message>
  </context>
  <context>
    <name>SelectBackgroundImage</name>
    <message>
      <source>Select Background</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Saved!</source>
      <translation type="unfinished"></translation>
    </message>
  </context>
  <context>
    <name>Settings</name>
    <message>
      <source>Manage device operators</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Calibration</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Device, Standard Solutions</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Calibration and Indexation</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Device, Standard Solutions, Cuvette</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Calibrating measurement unit</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Measurement Settings</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Advanced measurement settings</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Data Scheme</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Manage Account fields</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Manage sampling point fields</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Connections</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>WiFi, Bluetooth</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Security</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Lock screen</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Display</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Brightness, Homescreen</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Audio settings</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>General Settings</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Language, Date, Time</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Sound</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Signal Tones, Volume</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Device Information</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Serial Number, Software Version</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Settings</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Operators</source>
      <translation type="unfinished"></translation>
    </message>
  </context>
  <context>
    <name>SetupCloud</name>
    <message>
      <source>Connect to Cloud</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Login</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Register</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Skip</source>
      <translation type="unfinished"></translation>
    </message>
  </context>
  <context>
    <name>SetupCloudRegister</name>
    <message>
      <source>Cloud Register</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Email</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Password</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Repeat password</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Upload local data?</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Register</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Skip</source>
      <translation type="unfinished"></translation>
    </message>
  </context>
  <context>
    <name>SetupVessel</name>
    <message>
      <source>Enter LubeAnalyst Vessel Code</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>LubeAnalyst Vessel Code</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Confirm LubeAnalyst Vessel Code</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Save</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Vessel codes do not match!</source>
      <translation type="unfinished"></translation>
    </message>
  </context>
  <context>
    <name>Sound</name>
    <message>
      <source>Sound Settings</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Enable Sound</source>
      <translation type="unfinished"></translation>
    </message>
  </context>
  <context>
    <name>SoundSettings</name>
    <message>
      <source>Enable audio alerts</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Settings</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Sound</source>
      <translation type="unfinished"></translation>
    </message>
  </context>
  <context>
    <name>SpecialSettings</name>
    <message>
      <source>Enable Professional Mode</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>The professional mode deactivates all text phrases and animations during a measurement.</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Iron in Oil</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>10 - 300%</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Signal Intensity</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Saved !</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Check input !</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Measurement Settings</source>
      <translation type="unfinished"></translation>
    </message>
  </context>
  <context>
    <name>StartMeasurement</name>
    <message>
      <source>Professional mode enabled.</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Select Sampling Point</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Select Operator</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Select Parameter</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Water Sample</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Dilution Solution</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>You can define an individual dilution factor in order to increase the measurement range.</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Please note:</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>The step-by-step phrases during the measurement process do NOT consider any dilution settings, just the result will be calculated according to the selected dilution factor.</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Dilution increases the tolerances/accuracy of the measurement result</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Start measurement</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Please select account and parameter</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Selected Machine</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>You don't have any applications for this group!</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Application</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Operator</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Test</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Measurement range</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Favorite already exists!</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Favorite Overview</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Selected Parameter</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Selected Account</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Favorite Name</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Save</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Saved !</source>
      <translation type="unfinished"></translation>
    </message>
  </context>
  <context>
    <name>StatusbarExpandMenu</name>
    <message>
      <source>Please log in to your cloud account from the cloud menu</source>
      <translation type="unfinished"></translation>
    </message>
  </context>
  <context>
    <name>Support</name>
    <message>
      <source>PrimeLab 2.0 news feed</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Visit our website</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>All about the PrimeLab</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Get in contact with us</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Support</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>News</source>
      <translation type="unfinished"></translation>
    </message>
  </context>
  <context>
    <name>UpdateStore</name>
    <message>
      <source>installing update</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>The system is up to date</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Checking for updates</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Please check your internet connection</source>
      <translation type="unfinished"></translation>
    </message>
  </context>
  <context>
    <name>UserPrefsStore</name>
    <message>
      <source>Operator already exists !</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Saved!</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>setting language</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Already on Homescreen</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Added to Homescreen</source>
      <translation type="unfinished"></translation>
    </message>
  </context>
  <context>
    <name>WTPStore</name>
    <message>
      <source>piece</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>teaspoon</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>tablespoon</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>fluid ounce</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>shot</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>cup</source>
      <translation type="unfinished"></translation>
    </message>
  </context>
  <context>
    <name>WTPs</name>
    <message>
      <source>WT Products</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Filter</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Add WTP</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Delete selected WTPs</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Filter Products</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Filter active</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Select Group</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Are you sure to delete the selected products?</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Please confirm delete operation</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Are you sure to delete the selected product?</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Products</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Search</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Add Product</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Delete selected Products</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>No products selected</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>You don't have the permission for this operation.</source>
      <translation type="unfinished"></translation>
    </message>
  </context>
  <context>
    <name>Wifi</name>
    <message>
      <source>Successfully deleted</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Connecting to saved network</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Loading</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Already connected to this network.</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>WiFi</source>
      <translation type="unfinished"></translation>
    </message>
  </context>
  <context>
    <name>WifiSettings</name>
    <message>
      <source>WiFi connection deleted</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>WiFi</source>
      <translation type="unfinished"></translation>
    </message>
  </context>
  <context>
    <name>WifiSetup</name>
    <message>
      <source>If you let me enter your WiFi, I can scan for updates. Also you can link me to the cloud service in the next step. You can skip this setup step and configure it later on in the device settings.</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Skip</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>WiFi</source>
      <translation type="unfinished"></translation>
    </message>
  </context>
  <context>
    <name>WifiSetupConnect</name>
    <message>
      <source>Back</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>connecting ...</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Successfully connected</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Please check password</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Password</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Connect</source>
      <translation type="unfinished"></translation>
    </message>
  </context>
  <context>
    <name>config</name>
    <message>
      <source>piece(s)</source>
      <translation type="unfinished"></translation>
    </message>
  </context>
  <context>
    <name>main</name>
    <message>
      <source>Okay</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>You can't turn off the device while an update is loading.</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Warning, update in progress</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>The system is up to date</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Download all updates?</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Copy updates from USB drive?</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source> updates available</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Download ...</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>The system needs to be restarted. Restart now?</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Please retry later. Do you want to restart the system now?</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Installation complete</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Installation failed</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Later</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Start installation?</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>An error occured, please retry.</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Download complete</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Download failed</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Installing Update ...</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Please check your internet connection</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>The email is already taken, please log in.</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>The login details don't match. Please check email and password.</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Timestamp error</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>initalization in progress</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>loading data</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>buffering data</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>data ready</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>committing data</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>waiting for cloud service</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>I ran into an issue, I am trying to reload the database</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>I ran into an issue, going to restart my service</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>PrimeLab 2.0</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Battery too low, you can't take measurements or install updates below 15% battery charge.</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <source>Warning, battery low</source>
      <translation type="unfinished"></translation>
    </message>
  </context>
</TS>
